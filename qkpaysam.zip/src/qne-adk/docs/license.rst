License
=======

.. highlight:: none

.. literalinclude:: ../LICENSE

.. highlight:: default
