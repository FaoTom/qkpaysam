from netqasm.sdk.external import NetQASMConnection, Socket
from netqasm.sdk import EPRSocket
import random
from utils_function import S

def main(app_config=None, x=0, y=10):
    # Specify an EPR socket to bob
    epr_socket = EPRSocket("bob")
    # Setup a classical socket to bob
    socket = Socket("alice", "bob", log_config=app_config.log_config)

    alice_outputs = []

    alice = NetQASMConnection(
        "alice",
        log_config=app_config.log_config,
        epr_sockets=[epr_socket],
    )
    with alice:
        alice_basis = []
        for _ in range(10):
            base = random.randint(0,2)
            alice_basis.append(str(base))
            # Create an entangled pair using the EPR socket to bob
            q_ent = epr_socket.create()[0]
            # Measure the qubit
            q_ent.rot_Y(n=(base+1), d=2)
            m = q_ent.measure()
            alice.flush()
            alice_outputs.append(str(m))
    print('Alice outcomes:', alice_outputs)
    print('Alice basis are:', alice_basis)
    #Alice is sending to Bob her basis
    socket.send("".join(alice_basis))
    #Alice receives the basis from Bob
    bob_basis_received = socket.recv()
    bob_basis_received = [int(i) for i in bob_basis_received]
    print(f"alice received the bob basis: {bob_basis_received}")

if __name__ == "__main__": 
    main()
