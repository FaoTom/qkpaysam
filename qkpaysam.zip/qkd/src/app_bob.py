from netqasm.sdk.external import NetQASMConnection, Socket
from netqasm.sdk import EPRSocket
import random
from eve import Eve
from utils_function import S

def main(app_config=None, x=0, y=10):
    # Specify an EPR socket to bob
    epr_socket = EPRSocket("alice")
    eve = Eve()
    # Setup a classical socket to alice
    socket = Socket("bob", "alice", log_config=app_config.log_config)

    bob_outputs = []

    bob = NetQASMConnection(
        "bob",
        log_config=app_config.log_config,
        epr_sockets=[epr_socket],
    )
    with bob:
        bob_basis = []
        for _ in range(10):
            base = random.randint(0,2)
            bob_basis.append(str(base))
            # Receive an entangled pair using the EPR socket to alice
            q_ent = epr_socket.recv()[0]
            print(type(q_ent))
            m_eve = eve.eavesdrop(q_ent)
            # Measure the qubit
            q_ent.rot_Y(n=base, d=2)
            m = q_ent.measure()
            bob.flush()
            bob_outputs.append(str(m))
            print('misura di Eve', m_eve, 'misura di Bob', m)
    print('Bob outcomes:', bob_outputs)
    print('Bob basis are:', bob_basis)
    #Bob is sending to Alice his basis
    socket.send("".join(bob_basis))
    #Bob receives the basis from Alice
    alice_basis_received = socket.recv()
    alice_basis_received = [int(i) for i in alice_basis_received]
    print(f"bob received the alice basis: {alice_basis_received}")

if __name__ == "__main__": 
    main()
