import numpy as np

def S(diffBases):
    total_a1b2 = sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 2))

    p_a1b2_p = (sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 2) & (diffBases[:, 2] == 1) & (diffBases[:, 2] == 1)) +
                sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 2) & (diffBases[:, 2] == -1) & (diffBases[:, 3] == -1))) / total_a1b2
    p_a1b2_n = (sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 2) & (diffBases[:, 2] == -1) & (diffBases[:, 2] == 1)) + 
                sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 2) & (diffBases[:, 2] == 1) & (diffBases[:, 3] == -1))) / total_a1b2

    exp_a1b2 = p_a1b2_p - p_a1b2_n

    total_a1b3 = sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 3))

    p_a1b3_p = (sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 3) & (diffBases[:, 2] == 1) & (diffBases[:, 2] == 1)) +
                sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 3) & (diffBases[:, 2] == -1) & (diffBases[:, 3] == -1))) / total_a1b3
    p_a1b3_n = (sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 3) & (diffBases[:, 2] == -1) & (diffBases[:, 2] == 1)) +
                sum(diffBases[:, 0] == 1 & (diffBases[:, 1] == 3) & (diffBases[:, 2] == 1) & (diffBases[:, 3] == -1))) / total_a1b3

    exp_a1b3 = p_a1b3_p - p_a1b3_n

    total_a3b2 = sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 2))

    p_a3b2_p = (sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 2) & (diffBases[:, 2] == 1) & (diffBases[:, 2] == 1)) +
                sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 2) & (diffBases[:, 2] == -1) & (diffBases[:, 3] == -1))) / total_a3b2
    p_a3b2_n = (sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 2) & (diffBases[:, 2] == -1) & (diffBases[:, 2] == 1)) +
                sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 2) & (diffBases[:, 2] == 1) & (diffBases[:, 3] == -1))) / total_a3b2

    exp_a3b2 = p_a3b2_p - p_a3b2_n

    total_a3b3 = sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 2))

    p_a3b2_p = (sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 3) & (diffBases[:, 2] == 1) & (diffBases[:, 2] == 1)) +
                sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 3) & (diffBases[:, 2] == -1) & (diffBases[:, 3] == -1))) / total_a3b3
    p_a3b2_n = (sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 3) & (diffBases[:, 2] == -1) & (diffBases[:, 2] == 1)) +
                sum(diffBases[:, 0] == 3 & (diffBases[:, 1] == 3) & (diffBases[:, 2] == 1) & (diffBases[:, 3] == -1))) / total_a3b3

    exp_a3b3 = p_a3b2_p - p_a3b2_n

    return exp_a1b2 + exp_a1b3 + exp_a3b2 - exp_a3b3